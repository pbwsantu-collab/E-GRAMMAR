# English Grammar Master PWA

A mobile-first, offline-capable single-engine grammar PWA.

## Run
No npm/Vite is required.

For the simplest local test, open `index.html` in a modern browser.

For service-worker/offline testing, serve the folder over HTTP, for example:

```powershell
python -m http.server 5173
```

Then open `http://localhost:5173`.

## Deploy to GitHub Pages
Upload the contents of this folder to the repository's Pages branch/folder and enable GitHub Pages.

## Current engine
- Home → Modules → Lesson → Practice → Test → Result/Progress
- English + বাংলা explanations
- LocalStorage progress
- Mistake book
- Timed test engine
- 100-question mixed test mode
- Print support
- Responsive mobile/desktop UI
- Manifest + service worker for installability/offline caching
- No backend required for the core learning engine

## Content expansion
The content registry is intentionally modular. Supplied textbook rules should be added to the corresponding module without deleting or paraphrasing source material when source fidelity is required.
